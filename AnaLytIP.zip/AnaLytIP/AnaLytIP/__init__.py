"""
Package for AnaLytIP.
"""
