class DataCrawler(object):
    """description of class"""
    def CrawlerMethod(self):
        raise NotImplementedError


class BS4Crawler(DataCrawler):
    def CrawlerMethod(self):
        return super(BS4Crawler, self).CrawlerMethod()

